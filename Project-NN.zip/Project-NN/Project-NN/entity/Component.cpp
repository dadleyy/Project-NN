#include "Component.h"
#include "GameObject.h"

void Component::Init(GameObject* go) {
}

void Component::Update(float dt) {
}