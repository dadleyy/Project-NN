#include "GameState.h"

void GameState::Init(StateManager* manager)
{
	this->manager = manager;
}